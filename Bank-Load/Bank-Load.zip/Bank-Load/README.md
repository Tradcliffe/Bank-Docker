# AD-Capital-Load
